=======
History
=======

0.1.2 (2020-01-27)
------------------

* First release on PyPI.
* Completely removed slower Chudnovsky function.
  It didn't generate the correct sequence.
