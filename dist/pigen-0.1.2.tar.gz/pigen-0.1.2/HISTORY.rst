=======
History
=======

0.1.2 (2020-01-27)
------------------

* First release on PyPI.
